#!/usr/bin/env python3

#### IMPORTS ####
import pandas as pd
import matplotlib.pyplot as plt
import subprocess
from subprocess import STDOUT,PIPE
import os

#### INSTANCE VARIABLES ####

SubsetSizeArr = []
BestCaseArrBST = []
AverageCaseArrBST = []
WorstCaseArrBST = []
BestCaseArrArray = []
AverageCaseArrArray = []
WorstCaseArrArray = []
outputIntArr = []

# Creating an array containing all possible subset sizes
for i in range(500):
    SubsetSizeArr.append(i+1)

# Function that calls the PowerBSTAppTest java program on
# each subsetted dataset, reads in the output and calculates the best/worst/average case from that data.
def subsetCSVBST():
    counter = 0
    sum = 0
    for i in range(1,501):
        bestCase=0
        worstCase=0
        averageCase=0
        cmd = "head -n " + str(i+1) + " cleaned_data.csv > head_data.csv"
        subprocess.call(cmd, shell=True)
        cmd = "java PowerBSTAppTest head_data.csv " + str(i)
        p = subprocess.Popen(cmd, universal_newlines=True, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output = p.communicate()
        outputArr = output[0].split(",")
        if counter==0:
            for ops in outputArr:
                if ops != '':
                    ops = int(ops)
                    sum+=ops
                    outputIntArr.append(ops)
            counter +=1
        else:
            sum+=int(outputArr[-2])
            outputIntArr.append(int(outputArr[-2]))

        averageCase = sum//len(outputIntArr)
        AverageCaseArrBST.append(averageCase)

        bestCase = min(outputIntArr)
        BestCaseArrBST.append(bestCase)

        worstCase = max(outputIntArr)
        WorstCaseArrBST.append(worstCase)


# Function that simulates what the data would
# look like when applying the above function to PowerArrayApp.
def ArrayTest():
    sum = 0
    for i in range(1,501):
        sum+=i
        averageCase = sum//i
        AverageCaseArrArray.append(averageCase)

        bestCase = 1
        BestCaseArrArray.append(bestCase)

        worstCase = i
        WorstCaseArrArray.append(worstCase)

#### MAIN ####

if __name__ == "__main__":
     subsetCSVBST()
     d = {'Subset Size': SubsetSizeArr, 'Best Case': BestCaseArrBST, 'Average Case': AverageCaseArrBST, 'Worst Case': WorstCaseArrBST}
     BSTdf = pd.DataFrame(data=d)
     BSTdf.to_csv("BSTOutput.csv", sep='\t', encoding='utf-8')
     # print(BSTdf.head(10))
     BSTdf.plot(x = "Subset Size")
     plt.show()

     ArrayTest()
     d = {'Subset Size': SubsetSizeArr, 'Best Case': BestCaseArrArray, 'Average Case': AverageCaseArrArray, 'Worst Case': WorstCaseArrArray}
     Arraydf = pd.DataFrame(data=d)
     Arraydf.to_csv("ArrayOutput.csv", sep='\t', encoding='utf-8')
     #print(Arraydf.head(10))
     Arraydf.plot(x = "Subset Size")
     plt.show()
