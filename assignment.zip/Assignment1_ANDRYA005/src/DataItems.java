/** Represents a Data Item.
 * @author ANDRYA005
*/
public class DataItems{

  private String dateTime;
  private String power;
  private String voltage;


  /** Creates a Date/time object with the specified data items.
   * @param dateTime the date/time data item
   * @param power the power data item.
   * @param voltage the voltage data item.
  */
  public DataItems(String dateTime, String power, String voltage){
    this.dateTime = dateTime;
    this.power = power;
    this.voltage = voltage;
  }

  /** Gets the Date/time object's date/time.
   * @return A string representing the date/time component.
  */
  public String getDateTime(){
    return this.dateTime;
  }

  /** Gets the Date/time object's power.
   * @return A string representing the power component.
  */
  public String getPower(){
    return this.power;
  }

  /** Gets the Date/time object's voltage.
   * @return A string representing the voltage component.
  */
  public String getVoltage(){
    return this.voltage;
  }

  /** Method for comparing two DataItems objects based on their date/time values.
  * @param other The other DataItems object being compared.
  * @return An integer which is positive if the first string is lexicographically greater than the parameter string else the result would be negative.
  */
  public int compareTo(DataItems other){
    return this.dateTime.compareTo(other.getDateTime());
  }

  /** Method for checking equality of two DataItems objects based on their date/time value.
  * @return True if their date/times are equal, otherwise False.
  * @param other the DataItems object to be checked with.
  */
  public boolean equals(DataItems other){
    return this.dateTime.equals(other.getDateTime());
  }

  /** Method for returning the desired String representation of a DataItems object.
    * @return the desired String representation of a DataItems object.
    */
  public String toString(){
    return "Date/time: " + this.dateTime + "\n" + "Power: " + this.power + "\n" + "Voltage: " + this.voltage + "\n";
  }
}
