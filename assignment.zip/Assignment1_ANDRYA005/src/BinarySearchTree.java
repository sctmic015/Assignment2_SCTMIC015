/** Implementation of a BST.
 * @author https://algorithms.tutorialhorizon.com/binary-search-tree-complete-implementation/
*/

public class BinarySearchTree {


    public static Node root;
    public int opCounter; // instrumentation to count comparison

    public BinarySearchTree(){
  		this.root = null;
  	}

  	public DataItems find(String dateTime){
      opCounter = 0;
  		Node current = root;
  		while(current!=null){
        opCounter++;
  			if(current.data.getDateTime().equals(dateTime)){
  				return current.data;
  			}else if(current.data.getDateTime().compareTo(dateTime)>0){
  				current = current.left;
  			}else{
  				current = current.right;
  			}
  		}
  		return null;
  	}

  	public void insert(DataItems id){
  		Node newNode = new Node(id);
  		if(root==null){
  			root = newNode;
  			return;
  		}
  		Node current = root;
  		Node parent = null;
  		while(true){
  			parent = current;
  			if(id.compareTo(current.data)<0){
  				current = current.left;
  				if(current==null){
  					parent.left = newNode;
  					return;
  				}
  			}else{
  				current = current.right;
  				if(current==null){
  					parent.right = newNode;
  					return;
  				}
  			}
  		}
  	}
  	public void display(Node root){
  		if(root!=null){
  			display(root.left);
  			System.out.println(root.data);
  			display(root.right);
  		}
  	}

  }

  class Node{
  	DataItems data;
  	Node left;
  	Node right;
  	public Node(DataItems data){
  		this.data = data;
  		left = null;
  		right = null;
  	}
}
