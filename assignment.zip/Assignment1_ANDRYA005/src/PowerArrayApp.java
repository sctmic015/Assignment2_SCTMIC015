/** PowerArrayApp for storing DataItems in an array.
 * @author ANDRYA005
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class PowerArrayApp {

    private static int opCounter = 0; // instrumentation to count comparison
    private static DataItems[] dataItemsArray;

    /** Main method for reading in dataset and printing out the operation count for a given date/time.
    * @param args the date/time to search for.
    */
    public static void main(String[] args) {
        File file = new File("cleaned_data.csv");

        // this gives you a 2-dimensional array of strings
        dataItemsArray = new DataItems[500];
        Scanner inputStream;

        try {
            inputStream = new Scanner(file);
            int i = 0;
            int counter = 0;
            DataItems dataItem;
            while(inputStream.hasNext()){
                String line = inputStream.next();
                if (counter==0){ // in order to skip the headings
                  counter++;
                  continue;
                }
                String[] values = line.split(",");
                dataItem = new DataItems(values[0],values[1],values[3]);

                // this adds the currently parsed line to the 2-dimensional string array
                dataItemsArray[i] = dataItem;
                i++;
            }

            inputStream.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        if (args.length>0){
            printDateTime(args[0]);
            try{
              writeToFile(opCounter, args[0]);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        else{
            printAllDateTimes();
        }
    }

    /** Method to print out the Date/time, Power and Voltage values for
    * the matching dateTime record; or "Date/time not found" if there is no match.
    * @param dateTime String value of teh date/time queried.
    */
    public static void printDateTime (String dateTime){
        boolean found = false;
        for (int i = 0; i<500 ; i++){
          opCounter++;  // comparison operation
          if (dataItemsArray[i].getDateTime().equals(dateTime)){ // checking for equality
            System.out.println("Date/time: " + dataItemsArray[i].getDateTime());
            System.out.println("Power: " + dataItemsArray[i].getPower());
            System.out.println("Voltage: " + dataItemsArray[i].getVoltage());
            found = true; // true when object has been found
            break;
          }
        }
        if (found == false){
          System.out.println("Date/time not found");
        }
    }


    /** Method to print all the date/time objects in dataset.
    */
    public static void printAllDateTimes(){
      for (int i = 0; i<500 ; i++){
        System.out.println("Date/time: " + dataItemsArray[i].getDateTime());
        System.out.println("Power: " + dataItemsArray[i].getPower());
        System.out.println("Voltage: " + dataItemsArray[i].getVoltage());
        System.out.println("");
      }
    }

    /** Method for writing the number of operations used and Date/time queryed when querying a particular Date/time.
    * @throws IOException if fails to write opCounter to file.
    * @param opCounter int value for the number of operations used.
    * @param dateTime String value of the date/time queried.
    */
    public static void writeToFile(int opCounter, String dateTime)
      throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("opCounter.txt",true));
        writer.append("Date Structure: Array");
        writer.append('\n');
        writer.append("Operations: " + Integer.toString(opCounter));
        writer.append('\n');
        writer.append("Date/time queried: " + dateTime);
        writer.append('\n');
        writer.append('\n');
        writer.close();
    }

}
