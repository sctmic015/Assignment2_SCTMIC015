/** Modification of PowerArrayApp class for part 5.
 * @author ANDRYA005
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;


public class PowerBSTAppTest {

     private static BinarySearchTree tree;
     private static int opCounter = 0; // instrumentation to count comparison

     /** Main method for reading in dataset and printing out the operation count for a given date/time.
     * @param args the dataset to read in.
     */
     public static void main(String[] args) {
         File file = new File(args[0]);
         tree = new BinarySearchTree();
         Scanner inputStream;

         try {
             inputStream = new Scanner(file);
             int i = 0;
             int counter = 0;
             DataItems dataItem;
             while(inputStream.hasNext()){
                 String line = inputStream.next();
                 if (counter==0){ // in order to skip the headings
                   counter++;
                   continue;
                 }
                 String[] values = line.split(",");
                 dataItem = new DataItems(values[0],values[1],values[3]);
                 tree.insert(dataItem);
                 tree.opCounter = 0;
                 printDateTime(dataItem.getDateTime());
                 System.out.print(tree.opCounter + ",");
                 try{
                   writeToFile(tree.opCounter, dataItem.getDateTime());
                 }
                 catch (IOException e) {
                     e.printStackTrace();
                 }
             }
             inputStream.close();
         }
         catch (FileNotFoundException e) {
             e.printStackTrace();
         }
      }

      /** Method to print out the Date/time, Power and Voltage values for
      * the matching dateTime record; or "Date/time not found" if there is no match.
      * @param dateTime String value of the date/time queried.
      */
     public static void printDateTime (String dateTime){
        DataItems queryData = tree.find(dateTime);
        if (queryData==null){
           System.out.println("Date/time not found");
        }
     }

     /** Method for writing the number of operations used and Date/time queryed when querying a particular Date/time.
     * @throws IOException if fails to write opCounter to file.
     * @param opCounter int value for the number of operations used.
     * @param dateTime String value of the date/time queried.
     */
     public static void writeToFile(int opCounter, String dateTime)
       throws IOException {
         BufferedWriter writer = new BufferedWriter(new FileWriter("opCounterTestBST.txt",true));
         writer.append("Operations: " + Integer.toString(opCounter));
         writer.append('\n');
         writer.close();
     }



}
