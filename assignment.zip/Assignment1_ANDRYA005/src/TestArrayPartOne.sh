#!/bin/bash
# Script: for automating the testing process for part 1

java PowerArrayApp 17/12/2006/01:39:00 > FirstKnowndateTime_Part1.txt
java PowerArrayApp 16/12/2006/17:30:00 > SecondKnowndateTime_Part1.txt
java PowerArrayApp 16/12/2006/18:19:00 > ThirdKnowndateTime_Part1.txt

java PowerArrayApp 17/12/2006/01:39:01 > FirstUnknowndateTime_Part1.txt

java PowerArrayApp > NoParameter_Part1.txt


