#!/bin/bash
# Script: for automating the testing process for part 3

java PowerBSTApp 17/12/2006/01:39:00 > FirstKnowndateTime_Part3.txt
java PowerBSTApp 16/12/2006/17:30:00 > SecondKnowndateTime_Part3.txt
java PowerBSTApp 16/12/2006/18:19:00 > ThirdKnowndateTime_Part3.txt

java PowerBSTApp 17/12/2006/01:39:01 > FirstUnknowndateTime_Part3.txt

java PowerBSTApp > NoParameter_Part3.txt


