/** Modification of PowerArrayApp class for part 5.
 * @author ANDRYA005
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class PowerArrayAppTest{


  private static int opCounter = 0; // instrumentation to count comparison
  private static DataItems[] dataItemsArray;

  /** Main method for reading in dataset and printing out the operation count for a given date/time.
  * @param args the date/time to search for and size of subset.
  */
  public static void main(String[] args) {
      File file = new File(args[0]);

      // this gives you a 2-dimensional array of strings
      dataItemsArray = new DataItems[Integer.parseInt(args[1])];
      Scanner inputStream;

      try {
          inputStream = new Scanner(file);
          int i = 0;
          int counter = 0;
          DataItems dataItem;
          while(inputStream.hasNext()){
              String line = inputStream.next();
              if (counter==0){ // in order to skip the headings
                counter++;
                continue;
              }
              String[] values = line.split(",");
              dataItem = new DataItems(values[0],values[1],values[3]);
              dataItemsArray[i] = dataItem;
              i++;
          }
          inputStream.close();
      }
      catch (FileNotFoundException e) {
          e.printStackTrace();
      }
      for(DataItems data : dataItemsArray){
          opCounter = 0;
          printDateTime(data.getDateTime());
          System.out.println(opCounter);
      }

  }

  /** Method to print out the Date/time, Power and Voltage values for
  * the matching dateTime record; or "Date/time not found" if there is no match.
  * @param dateTime String value of teh date/time queried.
  */
  public static void printDateTime (String dateTime){
      boolean found = false;
      for(DataItems data : dataItemsArray){
        opCounter++;  // comparison operation
        if (data.getDateTime().equals(dateTime)){ // checking for equality
          // System.out.println(data.getDateTime());
          found = true; // true when object has been found
          try{
            writeToFile(opCounter, dateTime);
          }
          catch (IOException e) {
              e.printStackTrace();
          }
          break;
        }
      }
  }

  /** Method for writing the number of operations used and Date/time queryed when querying a particular Date/time.
  * @throws IOException if fails to write opCounter to file.
  * @param opCounter int value for the number of operations used.
  * @param dateTime String value of the date/time queried.
  */
  public static void writeToFile(int opCounter, String dateTime)
    throws IOException {
      BufferedWriter writer = new BufferedWriter(new FileWriter("opCounterTestArray.txt",true));
      writer.append("Date Structure: Array");
      writer.append('\n');
      writer.append("Operations: " + Integer.toString(opCounter));
      writer.append('\n');
      writer.append("Date/time queried: " + dateTime);
      writer.append('\n');
      writer.append('\n');
      writer.close();
  }

}
