/** PowerArrayApp for storing DataItems in an BST.
 * @author ANDRYA005
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;


public class PowerBSTApp {

     private static BinarySearchTree tree;
     private static int opCounter = 0; // instrumentation to count comparison

     /** Main method for reading in dataset and printing out the operation count for a given date/time.
     * @param args the date/time to search for.
     */
     public static void main(String[] args) {
         File file = new File("cleaned_data.csv");
         tree = new BinarySearchTree();
         Scanner inputStream;

         try {
             inputStream = new Scanner(file);
             int i = 0;
             int counter = 0;
             DataItems dataItem;
             while(inputStream.hasNext()){
                 String line = inputStream.next();
                 if (counter==0){ // in order to skip the headings
                   counter++;
                   continue;
                 }
                 String[] values = line.split(",");
                 String[] newValues = new String[3];
                 dataItem = new DataItems(values[0],values[1],values[3]);
                 tree.insert(dataItem);
             }

             inputStream.close();
         }
         catch (FileNotFoundException e) {
             e.printStackTrace();
         }

         if (args.length>0){
             printDateTime(args[0]);
             try{
               writeToFile(tree.opCounter, args[0]);
             }
             catch (IOException e) {
                 e.printStackTrace();
             }
         }
         else{
             printAllDateTimes();
         }
      }

    /** Method to print out the Date/time, Power and Voltage values for
    * the matching dateTime record; or "Date/time not found" if there is no match.
    * @param dateTime String value of the date/time queried.
    */
     public static void printDateTime (String dateTime){
        DataItems queryData = tree.find(dateTime);
        if (queryData!=null){
          System.out.println(queryData);
        }
        else{
          System.out.println("Date/time not found");
        }
     }


     /** Method to print all the date/time objects in dataset.
     */
     public static void printAllDateTimes(){
        tree.display(tree.root);
     }

     /** Method for writing the number of operations used and Date/time queryed when querying a particular Date/time.
     * @throws IOException if fails to write opCounter to file.
     * @param opCounter int value for the number of operations used.
     * @param dateTime String value of the date/time queried.
     */
     public static void writeToFile(int opCounter, String dateTime)
       throws IOException {
         BufferedWriter writer = new BufferedWriter(new FileWriter("opCounter.txt",true));
         writer.append("Date Structure: BST");
         writer.append('\n');
         writer.append("Operations: " + Integer.toString(opCounter));
         writer.append('\n');
         writer.append("Date/time queried: " + dateTime);
         writer.append('\n');
         writer.append('\n');
         writer.close();
     }



}
