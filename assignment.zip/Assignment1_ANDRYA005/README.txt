A few things to note:

NOTE ON RUNNING SOURCE FILES:

1. After running the "make" command, all the necessary compilations of source files and generation of javadocs happens, however, you will have to copy the compiled files into the src directory if you want to be able to run the source files.

NOTES ON AUTOMATED SCRIPTS:

All of my shell and python scripts are found in the src directory.

1. AutomatingPart5.py
	A Python script for automating part 5. If you run it, it will output the graphs which were used to summarise the output from the best/average/worst case from 		the two implementations.

2. TestArrayPartOne.sh
	A bash script to automate the testing process in part 1.

3. TestBSTPartThree.sh
	A bash script to automate the testing process in part 3.
